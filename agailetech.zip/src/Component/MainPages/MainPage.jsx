import React from 'react'

function MainPage() {
  return (
    <div>
      <h1 className='mt-10'>
        WELCOME TO AGILE HEALTH TECH
      </h1>
    </div>
  )
}

export default MainPage