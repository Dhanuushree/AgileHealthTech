import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { Button, Divider, Grid, Typography } from '@mui/material';

export default function UserProfile() {
  return (
    <>
    <div className='Nav'>
      <Grid container>
        <Grid item>
          <Box
            component="form"
            // sx={{
            //   '& > :not(style)': {  m: 1,width: '25ch' },
            // }}
            noValidate
            autoComplete="off"
          >
            <Typography variant="h6" noWrap component="div" >
            </Typography>
            <Typography variant="h6" noWrap component="div">

              <Button variant="contained"
                sx={{ ml: "63rem" }}
                color="primary">Edit</Button>
            </Typography>
            <br />
            <TextField id="standard-basic" label="Company Name" variant="standard" sx={{
              '& > :not(style)': { mr: "30ch", width: '25ch'  },
            }}
            />
            <TextField id="standard-basic" label="Contact Name" variant="standard" />
            <br />
            <TextField id="standard-basic" label="Email" variant="standard" sx={{
              '& > :not(style)': { mr: "30ch", width: '25ch' },
            }} />
            <TextField id="standard-basic" label="Phone No" variant="standard" />
          </Box>
        </Grid>
      </Grid>
      <br />
      <Divider />
      <Grid container>

        <Typography variant="h6" noWrap component="div" sx={4}>
          <TextField id="standard-basic" label="Corresponding Address" size="small" disabled variant="outlined" sx={{
            '& > :not(style)': { width: "13rem", pr: 3 },
          }} />

          <Button variant="contained" sx={{ ml: "50rem" }} color="primary">Edit</Button>
        </Typography>
        <Box
          component="form"
          sx={{
            '& > :not(style)': { m: 1, width: '20ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <TextField id="standard-basic" label="Address 1" variant="standard" />
          <TextField id="standard-basic" label="Address 2" variant="standard" />
          <TextField id="standard-basic" label="City " variant="standard" />
          <TextField id="standard-basic" label="State" variant="standard" />
          <TextField id="standard-basic" label="Zip" variant="standard" />

        </Box>
        <br />
      </Grid>
      <Divider />
      <Grid container>

        <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
          <TextField id="standard-basic" label="Billing Address" size="small" disabled variant="outlined" sx={{
            '& > :not(style)': { width: "13rem", pr: 3 },
          }} />

          <Button variant="contained" sx={{ ml: "50rem" }} color="primary">Edit</Button>
        </Typography>
        <Box
          component="form"
          sx={{
            '& > :not(style)': { m: 1, width: '20ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <TextField id="standard-basic" label="Address 1" variant="standard" />
          <TextField id="standard-basic" label="Address 2" variant="standard" />

          <TextField id="standard-basic" label="City " variant="standard" />
          <TextField id="standard-basic" label="State" variant="standard" />
          <TextField id="standard-basic" label="Zip" variant="standard" />

        </Box>
        <br />
        <Divider />
      </Grid>
    </div>
    </>

  );
}
