import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import { Button, ListItem, ListItemText, Modal, TextField } from '@mui/material';
import { Link, Route } from 'react-router-dom';
import UserProfile from '../MainPages/UserProfile';
import AgencyBusinessList from '../MainPages/AgencyBusinessList';
import CompanyProfile from '../MainPages/CompanyProfile';
import CustomerList from '../MainPages/CustomerList';
import MainPage from '../MainPages/MainPage';
import BrokerBusinessList from '../MainPages/BrokerBusinessList';
// import UserPage from '../MainPagesInBootstrap/UserPage';
// import { Router } from 'react-router-dom';


const drawerWidth = 200;


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const NavigationBar = () => {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        <Box sx={{ display: 'flex'}}>
            <CssBaseline />
            <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
                <Toolbar>
                    <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
                    </Typography>
                    <Typography variant="h6" noWrap component="div">
                        <Button variant="contained" sx={{ mr: 6 }} color="success" onClick={handleOpen}>Login User</Button>
                    </Typography>
                </Toolbar>
            </AppBar>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <TextField
                        label="UserName"
                        id="outlined-size-small"
                        size="small"
                    />
                    <TextField
                        label="Password"
                        id="outlined-size-small"
                        size="small"
                    />
                    <Button variant="cocntained" sx={{ ml: "8rem", mt: "1rem" }} onClick={handleClose}>Submit</Button>

                </Box>
            </Modal>
            <Drawer
                variant="permanent"
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
                }} >
                <Toolbar />
                <Box sx={{ overflow: 'auto' }}>
                    {/* <Divider /> */}
                    {/* <ListItemText primary={"MENU 1"} /> */}
                    <Divider />
                    <List>
                        <ListItem as={Link} to='/UserProfile'  >
                            <ListItemText primary={"User Profile Page"} />
                        </ListItem>
                        <ListItem as={Link} to='/CompanyProfile' >
                            <ListItemText primary={"Company Profile Page"} />
                        </ListItem>
                    </List>
                    {/* <Divider />
                    <ListItemText primary={"MENU 2"} /> */}
                    <Divider />
                    <List>
                        <ListItem as={Link} to='/CustomerList' >
                            <ListItemText primary={"Customer list page"} />
                        </ListItem>
                    </List>
                    <Divider />
                    <List>
                        <ListItem as={Link} to='/BrokerBusinessList' >
                            <ListItemText primary={"Broker Business page"} />
                        </ListItem>
                        <ListItem as={Link} to='/AgencyBusinessList' >
                            <ListItemText primary={"Agency Business page"} />
                        </ListItem>
                    </List>
                    <Divider />
                </Box>
            </Drawer>
            <Box component="main" sx={{ flexGrow: 1, m: "7ch" }}>
                <Toolbar />
                <Route exact path="/UserProfile" component={UserProfile} />
                {/* <Route exact path="/UserProfile" component={UserPage} /> */}
                <Route exact path="/BrokerBusinessList" component={BrokerBusinessList} />
                <Route exact path="/AgencyBusinessList" component={AgencyBusinessList} />
                <Route exact path="/CompanyProfile" component={CompanyProfile} />
                <Route exact path="/CustomerList" component={CustomerList} />
                <Route exact path="/" component={MainPage} />
            </Box>
        </Box>
    );
}

export default NavigationBar