import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Button } from '@mui/material';


export default function LoginPage() {
    return (
        <Card sx={{
          m:"auto", maxWidth: 400, maxHeight: 400, boxShadow: 15,
            
            bgcolor: (theme) => (theme.palette.mode === 'dark' ? '#101010' : '#fff'),
            color: (theme) =>
                theme.palette.mode === 'dark' ? 'grey.300' : 'grey.800',
             }} >
            <CardContent>
                <Box
                    component="form"
                    sx={{
                        '& .MuiTextField-root': { m: 2, width: '35ch' },
                    }}
                    noValidate
                    autoComplete="off"
                >
                    <div>
                        <TextField
                            label="UserName"
                            id="outlined-size-small"
                            size="small"
                        />
                    </div>
                    <div>
                        <TextField
                            label="Password"
                            id="outlined-size-small"
                            size="small"
                        />
                    </div>
                </Box>
                <Button variant="cocntained" sx={{ml:"8rem",mt:"1rem"}}>Submit</Button>

            </CardContent>

        </Card>
       
    );
}